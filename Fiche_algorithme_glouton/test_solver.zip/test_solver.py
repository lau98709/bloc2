# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 00:01:58 2019

@author: LAU Wai Tong Christian
"""

from labyrinthe_solver import *


TestSolver()